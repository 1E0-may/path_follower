%%find the loction
function [z]=sensor1(x,y)
    z=-(x^2+y^2)
end
