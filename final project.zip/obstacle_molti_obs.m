function obs = obstacle_molti_obs (start,goal) 
%% inputs
startpoint= start(1:2);
goalpoint = goal(1:2);
obspoint = [6 6 0 1 8 2 4 7];
[totRow,totCol]=size(obspoint) ;
sensor=1;
step=0.4*sensor;
alpha = 1.0;
miu = 1000;
NTPS= 600;
angel = 360/NTPS;
%% plot
hold on
plot (startpoint(1),startpoint(2),'d')
for j=(0:2:totCol-1)
plot (obspoint(j+1),obspoint(j+2),'*')
end
plot (goalpoint(1),goalpoint(2),'d')
xlim([0 15]);
ylim([0 15]);
grid on

%% loop
%% calc start potential
DFO= zeros(1,totCol/2);
obs_pote=zeros(1,totCol/2);
DTG = sqrt((startpoint(1)-goalpoint(1))^2+(startpoint(2)-goalpoint(2))^2);
k=1;
tot_obs_pote=0;
for j=(0:2:totCol-1)
    DFO(k) = sqrt((startpoint(1)-obspoint(j+1))^2+(startpoint(2)-obspoint(j+2))^2);
    k=k+1;
end
for i=(1:k-1)
    if DFO(i)>alpha
        obs_pote(i)=0;
    else
        obs_pote(i)=1/2* miu*((1/DFO(i))-(1/alpha))^2;
    end
end
for i=(1:k-1)
    tot_obs_pote= tot_obs_pote+obs_pote(i);
end
goal_pote = alpha*DTG^2;
tot_pote = tot_obs_pote+goal_pote;
%% CREATE POINTS
theta = zeros(1,NTPS);
theta (1) = angel;
bestx = zeros(1,NTPS);
besty = zeros(1,NTPS);
for i=(1:NTPS-1)
   theta(i+1)=theta(i)+angel;
   bestx(i)=startpoint(1)+cos(deg2rad(theta(i)))*0.5*DTG;
   besty(i)=startpoint(2)+sin(deg2rad(theta(i)))*0.5*DTG;
end
%% cost function 
JT_goal = zeros(1,NTPS);
temp_total= zeros(1,NTPS);
temp_DTG = zeros(1,NTPS);
dis_obs = zeros(1,k);
tot_JT_obs=zeros(1,NTPS);
JT_obs= zeros(1,k);
for i=(1:NTPS)
    h=1;
   dis_goal = sqrt(((bestx(i))-goalpoint(1))^2+(besty(i)-goalpoint(2))^2);
   for j=(1:k-1)
      dis_obs(j) = sqrt(((bestx(i))-obspoint(h))^2+(besty(i)-obspoint(h+1))^2); 
      h=h+2;
   end
for h=(1:k-1)
    if dis_obs(h)>alpha
        JT_obs(h)=0;
    else
        JT_obs(h)=1/2* miu*((1/dis_obs(h))-(1/alpha))^2;
    end
end
   JT_goal(i)= alpha*dis_goal^2;
 
   for h=(1:k-1)
    tot_JT_obs(i)= tot_JT_obs(i)+ JT_obs(h);
   end 
   temp_total(i)= tot_JT_obs(i)+JT_goal(i);
   temp_DTG(i)= sqrt((bestx(i)-goalpoint(1))^2 + (besty(i)-goalpoint(2))^2);
end
%% find the best point
% define error functions:
Check=0;
err_JT=zeros(1,NTPS);
err_DTG=zeros(1,NTPS);
for i=(1:NTPS)
   Check=Check+1;
   err_JT(i)= temp_total(i)- tot_pote;
   err_DTG(i)=temp_DTG(i)- DTG;
   vec = -err_DTG;
end
for k=(1:NTPS)
    [~,k]=min(err_JT+err_DTG);
    obs=[bestx(k),besty(k)];
%     if err_JT(k)<0
%         if err_DTG(k)<0
%             obs=[bestx(k),besty(k)];
%             startpoint(1)=bestx(k);
%             startpoint(2)=besty(k);
%             DTG = sqrt((startpoint(1)-goalpoint(1))^2 + (startpoint(2)-goalpoint(2))^2);
%             return 
%         else
%             vec(k)=0;
%         end
%     else      
%          vec(k)=0;
%     end
% end
% plot
% plot (startpoint(1),startpoint(2),'o')
end

