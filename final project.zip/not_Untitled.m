robot_state = [13 13 0];
robot_state(3) = sensor1(robot_state(1),robot_state(2));

sensor_prev = robot_state(3);
dir_step = [1 0];
matrix= [cos(0.25*pi) -sin(0.25*pi) ; sin(0.25*pi) cos(0.25*pi)];
step_size = 0.1;
move=dir_step*step_size
while(robot_state(3)< -1)
    i=i+1;
robot_state(1:2) = obstacle_molti_obs(robot_state(1:2),robot_state(1:2)+move)
robot_state(3) = sensor1(robot_state(1),robot_state(2))
if (robot_state(3)-sensor_prev < -0.0)
    dir_step = (matrix*dir_step')'
    move=dir_step*step_size
%     if (abs(robot_state(3)-sensor_prev) < 0.15)
%         step_size = step_size*10
%     else step_size = 0.1
%     end
end
    sensor_prev = robot_state(3)
end

% 
% 
% """     print (to_print/1000)
%     if to_print / 1000 == 0:
%         plt.plot(startpoint[0],startpoint[1],marker ='d')
%         for j in range (0,tot-1):
%             plt.plot (obspoint1[0],obspoint1[1],marker = '*')
%             plt.plot (obspoint2[0],obspoint2[1],marker ='*')
%         plt.plot (goalpoint[0],goalpoint[1],marker ='d')    
%         plt.show()
%         plt.grid() """  

